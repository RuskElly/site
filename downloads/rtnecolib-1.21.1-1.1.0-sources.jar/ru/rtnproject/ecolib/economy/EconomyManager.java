package ru.rtnproject.ecolib.economy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import ru.rtnproject.ecolib.EcoConfig;
import ru.rtnproject.ecolib.RTNEcoLib;
import ru.rtnproject.ecolib.api.EconomyResponse;
import ru.rtnproject.ecolib.api.RTNEconomyAPI;
import ru.rtnproject.ecolib.api.event.BalanceChangeEvent;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Server-side economy engine + MFM statistics. Implements the public API.
 * Data is held in memory and periodically flushed (encrypted) to disk by
 * {@link ServerLifecycleHandler}.
 */
public final class EconomyManager implements RTNEconomyAPI {

    private static final Gson GSON = new GsonBuilder().create();

    private record Account(double balance, String name, long kills, double earned) {
        Account withBalance(double b) {
            return new Account(b, name, kills, earned);
        }

        Account withName(String n) {
            return new Account(balance, n, kills, earned);
        }

        Account addKill(double earnedNow) {
            return new Account(balance, name, kills + 1, earned + earnedNow);
        }
    }

    private final MinecraftServer server;
    private final CryptoStorage storage;
    private final Path dataFile;
    private final Map<UUID, Account> accounts = new ConcurrentHashMap<>();
    private final AtomicBoolean dirty = new AtomicBoolean(false);

    // global multiplier
    private volatile double globalMultiplier = 1.0D;
    private volatile long multiplierExpiresAtMillis = 0L;

    // cached top (rebuilt every topUpdateMinutes)
    private volatile List<TopEntry> cachedBalanceTop = List.of();
    private volatile List<TopEntry> cachedEarnedTop = List.of();
    private volatile long topBuiltAt = 0L;

    public EconomyManager(MinecraftServer server, Path dataDir) throws IOException {
        this.server = server;
        this.storage = new CryptoStorage(dataDir.resolve("secret.key"));
        this.dataFile = dataDir.resolve("balances.rtn");
        load();
        rebuildTops();
    }

    // ------------------------------------------------------------------ API

    @Override
    public double getBalance(UUID player) {
        Account a = accounts.get(player);
        return a == null ? 0.0D : a.balance();
    }

    @Override
    public boolean has(UUID player, double amount) {
        return getBalance(player) >= amount - 1e-9;
    }

    @Override
    public EconomyResponse deposit(UUID player, double amount, String reason) {
        amount = round(amount);
        if (amount <= 0) {
            return EconomyResponse.fail(EconomyResponse.Status.INVALID_AMOUNT, "amount must be > 0");
        }
        double old = getBalance(player);
        BalanceChangeEvent event = new BalanceChangeEvent(
                player, BalanceChangeEvent.Type.DEPOSIT, old, amount, reason);
        if (NeoForge.EVENT_BUS.post(event).isCanceled()) {
            return EconomyResponse.fail(EconomyResponse.Status.CANCELLED, "cancelled by event");
        }
        double finalAmount = round(event.getAmount());
        Account updated = accounts.compute(player, (u, a) -> {
            double base = a == null ? 0 : a.balance();
            Account acc = a == null ? new Account(0, "", 0, 0) : a;
            return acc.withBalance(round(base + finalAmount));
        });
        markDirty();
        RTNEcoLib.LOGGER.debug("[RTN EcoLib] +{} to {} ({})", finalAmount, player, reason);
        return EconomyResponse.ok(finalAmount, updated.balance());
    }

    @Override
    public EconomyResponse withdraw(UUID player, double amount, String reason) {
        amount = round(amount);
        if (amount <= 0) {
            return EconomyResponse.fail(EconomyResponse.Status.INVALID_AMOUNT, "amount must be > 0");
        }
        double old = getBalance(player);
        if (old + 1e-9 < amount) {
            return EconomyResponse.fail(EconomyResponse.Status.INSUFFICIENT_FUNDS,
                    "balance " + old + " < " + amount);
        }
        BalanceChangeEvent event = new BalanceChangeEvent(
                player, BalanceChangeEvent.Type.WITHDRAW, old, amount, reason);
        if (NeoForge.EVENT_BUS.post(event).isCanceled()) {
            return EconomyResponse.fail(EconomyResponse.Status.CANCELLED, "cancelled by event");
        }
        double finalAmount = round(event.getAmount());
        Account updated = accounts.compute(player, (u, a) -> {
            Account acc = a == null ? new Account(0, "", 0, 0) : a;
            return acc.withBalance(round(acc.balance() - finalAmount));
        });
        markDirty();
        return EconomyResponse.ok(finalAmount, updated.balance());
    }

    @Override
    public EconomyResponse setBalance(UUID player, double amount, String reason) {
        amount = round(amount);
        if (amount < 0) {
            return EconomyResponse.fail(EconomyResponse.Status.INVALID_AMOUNT, "amount must be >= 0");
        }
        double old = getBalance(player);
        BalanceChangeEvent event = new BalanceChangeEvent(
                player, BalanceChangeEvent.Type.SET, old, amount, reason);
        if (NeoForge.EVENT_BUS.post(event).isCanceled()) {
            return EconomyResponse.fail(EconomyResponse.Status.CANCELLED, "cancelled by event");
        }
        double finalAmount = round(event.getAmount());
        Account updated = accounts.compute(player, (u, a) ->
                (a == null ? new Account(0, "", 0, 0) : a).withBalance(finalAmount));
        markDirty();
        return EconomyResponse.ok(finalAmount, updated.balance());
    }

    @Override
    public EconomyResponse transfer(UUID from, UUID to, double amount, String reason) {
        EconomyResponse w = withdraw(from, amount, "transfer to " + to + ": " + reason);
        if (!w.success()) {
            return w;
        }
        EconomyResponse d = deposit(to, amount, "transfer from " + from + ": " + reason);
        if (!d.success()) {
            deposit(from, amount, "transfer rollback"); // rollback
            return d;
        }
        return w;
    }

    @Override
    public List<TopEntry> getTop(int limit) {
        List<TopEntry> top = cachedBalanceTop;
        return top.size() <= limit ? top : top.subList(0, limit);
    }

    public List<TopEntry> getEarnedTop(int limit) {
        List<TopEntry> top = cachedEarnedTop;
        return top.size() <= limit ? top : top.subList(0, limit);
    }

    @Override
    public String currencySymbol() {
        return EcoConfig.CURRENCY_SYMBOL.get();
    }

    @Override
    public String format(double amount) {
        double r = round(amount);
        String num = (r == Math.floor(r) && Math.abs(r) < 1e15)
                ? String.valueOf((long) r)
                : String.format(java.util.Locale.ROOT, "%.2f", r);
        return num + " " + currencySymbol();
    }

    @Override
    public double getGlobalMultiplier() {
        if (multiplierExpiresAtMillis > 0 && System.currentTimeMillis() > multiplierExpiresAtMillis) {
            globalMultiplier = 1.0D;
            multiplierExpiresAtMillis = 0L;
        }
        return globalMultiplier;
    }

    @Override
    public void setGlobalMultiplier(double multiplier, long durationSeconds) {
        if (durationSeconds <= 0 || multiplier == 1.0D) {
            globalMultiplier = 1.0D;
            multiplierExpiresAtMillis = 0L;
        } else {
            globalMultiplier = multiplier;
            multiplierExpiresAtMillis = System.currentTimeMillis() + durationSeconds * 1000L;
        }
    }

    /** Seconds left for the global multiplier, 0 when inactive. */
    public long multiplierSecondsLeft() {
        if (getGlobalMultiplier() == 1.0D) {
            return 0;
        }
        return Math.max(0, (multiplierExpiresAtMillis - System.currentTimeMillis()) / 1000L);
    }

    @Override
    public Optional<PlayerStats> getStats(UUID player) {
        Account a = accounts.get(player);
        return a == null ? Optional.empty()
                : Optional.of(new PlayerStats(player, a.kills(), round(a.earned())));
    }

    @Override
    public MinecraftServer server() {
        return server;
    }

    // ------------------------------------------------------------ internals

    public void recordKill(UUID player, double earnedNow) {
        accounts.compute(player, (u, a) ->
                (a == null ? new Account(0, "", 0, 0) : a).addKill(earnedNow));
        markDirty();
    }

    public void onPlayerJoin(ServerPlayer player) {
        UUID id = player.getUUID();
        String name = player.getGameProfile().getName();
        accounts.compute(id, (u, a) -> {
            if (a == null) {
                double start = EcoConfig.STARTING_BALANCE.get();
                if (start > 0) {
                    RTNEcoLib.LOGGER.info("[RTN EcoLib] new account {} start balance {}", name, start);
                }
                return new Account(round(start), name, 0, 0);
            }
            return a.withName(name);
        });
        markDirty();
    }

    /** Resolves a player name to UUID from known accounts (offline players too). */
    public Optional<UUID> findByName(String name) {
        for (Map.Entry<UUID, Account> e : accounts.entrySet()) {
            if (e.getValue().name().equalsIgnoreCase(name)) {
                return Optional.of(e.getKey());
            }
        }
        return Optional.empty();
    }

    public String nameOf(UUID uuid) {
        Account a = accounts.get(uuid);
        return a == null || a.name().isEmpty() ? uuid.toString() : a.name();
    }

    public void maybeRebuildTops() {
        long interval = EcoConfig.TOP_UPDATE_MINUTES.get() * 60_000L;
        if (System.currentTimeMillis() - topBuiltAt >= interval) {
            rebuildTops();
        }
    }

    public void rebuildTops() {
        List<TopEntry> byBalance = new ArrayList<>();
        List<TopEntry> byEarned = new ArrayList<>();
        accounts.forEach((uuid, a) -> {
            byBalance.add(new TopEntry(uuid, a.name(), round(a.balance())));
            byEarned.add(new TopEntry(uuid, a.name(), round(a.earned())));
        });
        byBalance.sort(Comparator.comparingDouble(TopEntry::balance).reversed());
        byEarned.sort(Comparator.comparingDouble(TopEntry::balance).reversed());
        cachedBalanceTop = List.copyOf(byBalance.subList(0, Math.min(100, byBalance.size())));
        cachedEarnedTop = List.copyOf(byEarned.subList(0, Math.min(100, byEarned.size())));
        topBuiltAt = System.currentTimeMillis();
    }

    private void markDirty() {
        dirty.set(true);
    }

    public boolean isDirty() {
        return dirty.get();
    }

    // ----------------------------------------------------------- persistence

    public synchronized void save(boolean force) {
        if (!force && !dirty.get()) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            root.addProperty("version", 1);
            JsonArray arr = new JsonArray();
            accounts.forEach((uuid, a) -> {
                JsonObject o = new JsonObject();
                o.addProperty("uuid", uuid.toString());
                o.addProperty("name", a.name());
                o.addProperty("balance", round(a.balance()));
                o.addProperty("kills", a.kills());
                o.addProperty("earned", round(a.earned()));
                arr.add(o);
            });
            root.add("accounts", arr);
            storage.writeEncrypted(dataFile, GSON.toJson(root));
            dirty.set(false);
            RTNEcoLib.LOGGER.debug("[RTN EcoLib] saved {} accounts (encrypted).", accounts.size());
        } catch (IOException e) {
            RTNEcoLib.LOGGER.error("[RTN EcoLib] failed to save balances!", e);
        }
    }

    private void load() throws IOException {
        String json = storage.readEncrypted(dataFile);
        if (json == null) {
            RTNEcoLib.LOGGER.info("[RTN EcoLib] no existing balance file, starting fresh.");
            return;
        }
        JsonObject root = GSON.fromJson(json, JsonObject.class);
        JsonArray arr = root.getAsJsonArray("accounts");
        for (var el : arr) {
            JsonObject o = el.getAsJsonObject();
            UUID uuid = UUID.fromString(o.get("uuid").getAsString());
            String name = o.has("name") ? o.get("name").getAsString() : "";
            double balance = o.get("balance").getAsDouble();
            long kills = o.has("kills") ? o.get("kills").getAsLong() : 0L;
            double earned = o.has("earned") ? o.get("earned").getAsDouble() : 0.0D;
            accounts.put(uuid, new Account(balance, name, kills, earned));
        }
        RTNEcoLib.LOGGER.info("[RTN EcoLib] loaded {} accounts from encrypted storage.", accounts.size());
    }

    public static double round(double v) {
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
}

package ru.rtnproject.ecolib.economy;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.fml.loading.FMLPaths;
import ru.rtnproject.ecolib.EcoConfig;
import ru.rtnproject.ecolib.RTNEcoLib;
import ru.rtnproject.ecolib.api.RTNEconomyProvider;
import ru.rtnproject.ecolib.mfm.ComboTracker;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Creates/destroys the {@link EconomyManager} with the server lifecycle,
 * runs the periodic encrypted save and hourly top rebuild.
 * All of this happens ONLY on the logical server.
 */
public final class ServerLifecycleHandler {

    private static EconomyManager manager;
    private int tickCounter = 0;

    public static EconomyManager manager() {
        return manager;
    }

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        try {
            Path dataDir = EcoConfig.PER_WORLD_STORAGE.get()
                    ? server.getWorldPath(LevelResource.ROOT).resolve("rtnecolib")
                    : FMLPaths.GAMEDIR.get().resolve("rtnecolib");
            EcoConfig.rebuildCaches();
            manager = new EconomyManager(server, dataDir);
            RTNEconomyProvider._set(manager);
            RTNEcoLib.LOGGER.info("[RTN EcoLib] economy started, data dir: {}", dataDir);
        } catch (IOException e) {
            throw new RuntimeException("[RTN EcoLib] cannot initialise encrypted storage", e);
        }
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        if (manager != null) {
            manager.save(true);
            RTNEcoLib.LOGGER.info("[RTN EcoLib] final save done.");
        }
        RTNEconomyProvider._set(null);
        manager = null;
        ComboTracker.clearAll();
    }

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        if (manager == null) {
            return;
        }
        tickCounter++;
        int saveTicks = EcoConfig.SAVE_INTERVAL_SECONDS.get() * 20;
        if (tickCounter % saveTicks == 0) {
            manager.save(false);
        }
        if (tickCounter % (20 * 60) == 0) { // once a minute check top rebuild
            manager.maybeRebuildTops();
        }
        if (tickCounter % 20 == 0) { // combo expiry + action bar updates
            ComboTracker.tickSecond(event.getServer());
        }
    }

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (manager != null && event.getEntity() instanceof ServerPlayer sp) {
            manager.onPlayerJoin(sp);
        }
    }

    @SubscribeEvent
    public void onPlayerLeave(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            ComboTracker.clear(sp.getUUID());
        }
    }
}

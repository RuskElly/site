package ru.rtnproject.ecolib.economy;

import ru.rtnproject.ecolib.RTNEcoLib;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.Arrays;

/**
 * AES-256-GCM encrypted file storage. SERVER SIDE ONLY.
 * <p>
 * The key is auto-generated on first start and kept in {@code secret.key}
 * inside the mod data folder. File format: magic "RTN1" + 12-byte IV +
 * ciphertext (GCM tag included). Writes are atomic (tmp + move) and a .bak
 * copy of the previous file is kept.
 */
public final class CryptoStorage {

    private static final byte[] MAGIC = {'R', 'T', 'N', '1'};
    private static final int GCM_TAG_BITS = 128;
    private static final int IV_LEN = 12;

    private final SecretKeySpec key;
    private final SecureRandom random = new SecureRandom();

    public CryptoStorage(Path keyFile) throws IOException {
        this.key = new SecretKeySpec(loadOrCreateKey(keyFile), "AES");
    }

    private byte[] loadOrCreateKey(Path keyFile) throws IOException {
        if (Files.exists(keyFile)) {
            byte[] raw = Files.readAllBytes(keyFile);
            if (raw.length != 32) {
                throw new IOException("Corrupted key file: " + keyFile);
            }
            return raw;
        }
        byte[] raw = new byte[32];
        new SecureRandom().nextBytes(raw);
        Files.createDirectories(keyFile.getParent());
        Files.write(keyFile, raw, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        try {
            // best-effort: restrict permissions on POSIX systems
            Files.setPosixFilePermissions(keyFile,
                    java.nio.file.attribute.PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException ignored) {
        }
        RTNEcoLib.LOGGER.info("[RTN EcoLib] Generated new AES-256 key: {}", keyFile);
        return raw;
    }

    /** Encrypts the given UTF-8 string and writes it atomically to {@code file}. */
    public synchronized void writeEncrypted(Path file, String plainText) throws IOException {
        try {
            byte[] iv = new byte[IV_LEN];
            random.nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            byte[] ct = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

            byte[] out = new byte[MAGIC.length + IV_LEN + ct.length];
            System.arraycopy(MAGIC, 0, out, 0, MAGIC.length);
            System.arraycopy(iv, 0, out, MAGIC.length, IV_LEN);
            System.arraycopy(ct, 0, out, MAGIC.length + IV_LEN, ct.length);

            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.write(tmp, out, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            if (Files.exists(file)) {
                Files.copy(file, file.resolveSibling(file.getFileName() + ".bak"),
                        StandardCopyOption.REPLACE_EXISTING);
            }
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Encryption failed", e);
        }
    }

    /** Reads and decrypts {@code file}; returns null when the file does not exist. */
    public synchronized String readEncrypted(Path file) throws IOException {
        if (!Files.exists(file)) {
            return null;
        }
        byte[] raw = Files.readAllBytes(file);
        if (raw.length < MAGIC.length + IV_LEN + 16
                || !Arrays.equals(Arrays.copyOfRange(raw, 0, MAGIC.length), MAGIC)) {
            throw new IOException("Not an RTN EcoLib encrypted file: " + file);
        }
        try {
            byte[] iv = Arrays.copyOfRange(raw, MAGIC.length, MAGIC.length + IV_LEN);
            byte[] ct = Arrays.copyOfRange(raw, MAGIC.length + IV_LEN, raw.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IOException("Decryption failed (wrong key or corrupted data): " + file, e);
        }
    }
}

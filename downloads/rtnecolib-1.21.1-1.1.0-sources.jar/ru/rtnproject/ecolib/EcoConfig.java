package ru.rtnproject.ecolib;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Common configuration (config/rtnecolib-common.toml).
 */
public final class EcoConfig {

    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<String> CURRENCY_SYMBOL;
    public static final ModConfigSpec.DoubleValue STARTING_BALANCE;
    public static final ModConfigSpec.IntValue SAVE_INTERVAL_SECONDS;
    public static final ModConfigSpec.BooleanValue PER_WORLD_STORAGE;

    public static final ModConfigSpec.DoubleValue PASSIVE_REWARD;
    public static final ModConfigSpec.DoubleValue HOSTILE_REWARD;
    public static final ModConfigSpec.DoubleValue BOSS_REWARD;
    public static final ModConfigSpec.DoubleValue BOSS_HEALTH_THRESHOLD;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> ENTITY_OVERRIDES;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> BOSS_ENTITIES;

    public static final ModConfigSpec.IntValue COMBO_WINDOW_SECONDS;
    public static final ModConfigSpec.IntValue COMBO_MAX;
    public static final ModConfigSpec.BooleanValue ACTION_BAR;

    public static final ModConfigSpec.IntValue TOP_UPDATE_MINUTES;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.push("economy");
        CURRENCY_SYMBOL = b.comment("Currency symbol shown in all messages.")
                .define("currencySymbol", "\u00AE");
        STARTING_BALANCE = b.comment("Balance given to a player on first join.")
                .defineInRange("startingBalance", 0.0D, 0.0D, 1_000_000_000.0D);
        SAVE_INTERVAL_SECONDS = b.comment("Save interval for the encrypted balance file, in seconds.")
                .defineInRange("saveIntervalSeconds", 300, 10, 86_400);
        PER_WORLD_STORAGE = b.comment("true = store data inside the world folder instead of <game dir>/rtnecolib.")
                .define("perWorldStorage", false);
        b.pop();

        b.push("mobRewards");
        PASSIVE_REWARD = b.comment("Reward for passive mobs.")
                .defineInRange("passiveReward", 1.0D, 0.0D, 1_000_000.0D);
        HOSTILE_REWARD = b.comment("Reward for hostile mobs.")
                .defineInRange("hostileReward", 5.0D, 0.0D, 1_000_000.0D);
        BOSS_REWARD = b.comment("Reward for bosses.")
                .defineInRange("bossReward", 100.0D, 0.0D, 1_000_000.0D);
        BOSS_HEALTH_THRESHOLD = b.comment("Mobs with max health >= this value count as bosses (covers modded bosses).")
                .defineInRange("bossHealthThreshold", 100.0D, 20.0D, 100_000.0D);
        ENTITY_OVERRIDES = b.comment("Per-entity reward overrides: \"modid:entity_id=amount\".")
                .defineListAllowEmpty("entityOverrides",
                        List.of("minecraft:ender_dragon=500", "minecraft:wither=250"),
                        o -> o instanceof String s && s.contains("="));
        BOSS_ENTITIES = b.comment("Entity ids always treated as bosses: \"modid:entity_id\".")
                .defineListAllowEmpty("bossEntities", List.of(),
                        o -> o instanceof String s && s.contains(":"));
        b.pop();

        b.push("combo");
        COMBO_WINDOW_SECONDS = b.comment("Seconds to kill the next mob before the combo resets.")
                .defineInRange("comboWindowSeconds", 5, 1, 120);
        COMBO_MAX = b.comment("Maximum combo multiplier.")
                .defineInRange("comboMax", 3, 1, 100);
        ACTION_BAR = b.comment("Show combo / income in the action bar.")
                .define("actionBarEnabled", true);
        b.pop();

        b.push("stats");
        TOP_UPDATE_MINUTES = b.comment("Rebuild interval for /mfm top cache, in minutes.")
                .defineInRange("topUpdateMinutes", 60, 1, 1_440);
        b.pop();

        SPEC = b.build();
    }

    // ------- parsed caches (rebuilt by /balreload and on server start) -------

    private static volatile Map<ResourceLocation, Double> overrides = Map.of();
    private static volatile Set<ResourceLocation> bosses = Set.of();

    /**
     * Migrates values from configs written by older mod versions.
     * The old config file is read and kept as-is — only the deprecated
     * currency symbol U+211F (renders as a square in the vanilla font)
     * is replaced with the new default.
     */
    public static void migrateOldConfig() {
        try {
            if ("\u211F".equals(CURRENCY_SYMBOL.get())) {
                CURRENCY_SYMBOL.set("\u00AE");
                RTNEcoLib.LOGGER.info("[RTN EcoLib] migrated old currency symbol U+211F -> \u00AE in config.");
            }
            if (BOSS_HEALTH_THRESHOLD.get() == 150.0D) {
                BOSS_HEALTH_THRESHOLD.set(100.0D);
                RTNEcoLib.LOGGER.info("[RTN EcoLib] migrated old bossHealthThreshold 150 -> 100 in config.");
            }
        } catch (IllegalStateException ignored) {
            // config not loaded yet — nothing to migrate
        }
    }

    public static void rebuildCaches() {
        migrateOldConfig();
        Map<ResourceLocation, Double> ov = new HashMap<>();
        for (String s : ENTITY_OVERRIDES.get()) {
            int i = s.lastIndexOf('=');
            if (i <= 0) continue;
            try {
                ResourceLocation id = ResourceLocation.parse(s.substring(0, i).trim());
                double amount = Double.parseDouble(s.substring(i + 1).trim());
                ov.put(id, amount);
            } catch (Exception e) {
                RTNEcoLib.LOGGER.warn("[RTN EcoLib] bad entityOverrides entry: '{}'", s);
            }
        }
        Set<ResourceLocation> bs = new HashSet<>();
        for (String s : BOSS_ENTITIES.get()) {
            try {
                bs.add(ResourceLocation.parse(s.trim()));
            } catch (Exception e) {
                RTNEcoLib.LOGGER.warn("[RTN EcoLib] bad bossEntities entry: '{}'", s);
            }
        }
        overrides = Map.copyOf(ov);
        bosses = Set.copyOf(bs);
    }

    public static Double overrideFor(ResourceLocation id) {
        return overrides.get(id);
    }

    public static boolean isConfiguredBoss(ResourceLocation id) {
        return bosses.contains(id);
    }

    private EcoConfig() {
    }
}

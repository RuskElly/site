package ru.rtnproject.ecolib;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import ru.rtnproject.ecolib.command.CommandRegistrar;
import ru.rtnproject.ecolib.economy.ServerLifecycleHandler;
import ru.rtnproject.ecolib.mfm.MobRewardHandler;

/**
 * RTN EcoLib — economy library mod for the RTN Project.
 * <p>
 * Server-side: economy engine, encrypted balance storage, Money-From-Mobs
 * rewards with combo system, commands.
 * Client-side: nothing special is required — action bar messages are sent by
 * the server; the mod is safe to install on both sides.
 * <p>
 * Public API for other RTN mods: {@link ru.rtnproject.ecolib.api.RTNEconomyAPI}
 * and the events in {@code ru.rtnproject.ecolib.api.event}.
 */
@Mod(RTNEcoLib.MODID)
public final class RTNEcoLib {

    public static final String MODID = "rtnecolib";
    public static final Logger LOGGER = LogUtils.getLogger();

    public RTNEcoLib(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, EcoConfig.SPEC);

        NeoForge.EVENT_BUS.register(new ServerLifecycleHandler());
        NeoForge.EVENT_BUS.register(new MobRewardHandler());
        NeoForge.EVENT_BUS.register(new CommandRegistrar());

        LOGGER.info("[RTN EcoLib] initialised (mod id '{}', economy + MFM + API).", MODID);
    }
}

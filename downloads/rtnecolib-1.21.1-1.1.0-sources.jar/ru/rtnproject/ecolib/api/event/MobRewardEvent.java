package ru.rtnproject.ecolib.api.event;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;

/**
 * Fired on the NeoForge event bus <b>before</b> a Money-From-Mobs reward is
 * paid out. Works for vanilla and modded entities alike.
 * <p>
 * Other RTN mods can:
 * <ul>
 *   <li>change the reward: {@link #setReward(double)} — e.g. custom price for
 *       their own bosses;</li>
 *   <li>mark their entity as a boss: {@link #setBoss(boolean)};</li>
 *   <li>cancel the payout entirely (e.g. mobs from a farm region).</li>
 * </ul>
 *
 * The final payout is {@code reward * combo * globalMultiplier}.
 */
public class MobRewardEvent extends Event implements ICancellableEvent {

    private final ServerPlayer killer;
    private final LivingEntity victim;
    private double reward;
    private boolean boss;
    private final int combo;
    private final double globalMultiplier;

    public MobRewardEvent(ServerPlayer killer, LivingEntity victim, double reward,
                          boolean boss, int combo, double globalMultiplier) {
        this.killer = killer;
        this.victim = victim;
        this.reward = reward;
        this.boss = boss;
        this.combo = combo;
        this.globalMultiplier = globalMultiplier;
    }

    public ServerPlayer getKiller() {
        return killer;
    }

    public LivingEntity getVictim() {
        return victim;
    }

    /** Base reward before combo and global multiplier are applied. */
    public double getReward() {
        return reward;
    }

    public void setReward(double reward) {
        this.reward = reward;
    }

    public boolean isBoss() {
        return boss;
    }

    public void setBoss(boolean boss) {
        this.boss = boss;
    }

    /** Current combo multiplier of the killer (1..comboMax). */
    public int getCombo() {
        return combo;
    }

    /** Current global multiplier (see /mfm multiplier). */
    public double getGlobalMultiplier() {
        return globalMultiplier;
    }
}

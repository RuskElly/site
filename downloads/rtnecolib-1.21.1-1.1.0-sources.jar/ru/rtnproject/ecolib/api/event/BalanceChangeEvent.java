package ru.rtnproject.ecolib.api.event;

import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;

import java.util.UUID;

/**
 * Fired on the NeoForge event bus <b>before</b> any balance modification made
 * through {@link ru.rtnproject.ecolib.api.RTNEconomyAPI}.
 * <p>
 * Other RTN mods can listen to audit or cancel transactions:
 *
 * <pre>{@code
 * @SubscribeEvent
 * public void onBalance(BalanceChangeEvent e) {
 *     if (e.getType() == BalanceChangeEvent.Type.WITHDRAW && e.getAmount() > 10000) {
 *         e.setCanceled(true); // block suspiciously large withdrawal
 *     }
 * }
 * }</pre>
 */
public class BalanceChangeEvent extends Event implements ICancellableEvent {

    public enum Type {DEPOSIT, WITHDRAW, SET}

    private final UUID player;
    private final Type type;
    private final double oldBalance;
    private double amount;
    private final String reason;

    public BalanceChangeEvent(UUID player, Type type, double oldBalance, double amount, String reason) {
        this.player = player;
        this.type = type;
        this.oldBalance = oldBalance;
        this.amount = amount;
        this.reason = reason;
    }

    public UUID getPlayer() {
        return player;
    }

    public Type getType() {
        return type;
    }

    public double getOldBalance() {
        return oldBalance;
    }

    public double getAmount() {
        return amount;
    }

    /** Listeners may adjust the transaction amount. */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getReason() {
        return reason;
    }
}

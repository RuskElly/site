package ru.rtnproject.ecolib.api;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * <h1>RTN EcoLib public API</h1>
 *
 * Stable entry point for all other RTN Project mods. Depend on rtnecolib as
 * {@code compileOnly} and access the economy through this interface:
 *
 * <pre>{@code
 * RTNEconomyAPI eco = RTNEconomyProvider.get();
 * eco.deposit(playerUuid, 100.0, "quest reward");
 * }</pre>
 *
 * All methods are <b>server-side only</b> and must be called from the server
 * thread. Amounts are doubles; the implementation rounds to 2 decimal places.
 *
 * @see RTNEconomyProvider
 * @see ru.rtnproject.ecolib.api.event.BalanceChangeEvent
 * @see ru.rtnproject.ecolib.api.event.MobRewardEvent
 */
public interface RTNEconomyAPI {

    /** @return current balance of the player (0 if unknown). */
    double getBalance(UUID player);

    /** @return true if the player has at least {@code amount}. */
    boolean has(UUID player, double amount);

    /**
     * Adds money to the account.
     *
     * @param reason free-form audit string (shown in logs), e.g. "quest reward".
     * @return the transaction result.
     */
    EconomyResponse deposit(UUID player, double amount, String reason);

    /**
     * Removes money from the account. Fails with
     * {@link EconomyResponse.Status#INSUFFICIENT_FUNDS} if balance is too low.
     */
    EconomyResponse withdraw(UUID player, double amount, String reason);

    /** Sets the balance to an exact value (admin/API use). */
    EconomyResponse setBalance(UUID player, double amount, String reason);

    /** Atomic player-to-player transfer. */
    EconomyResponse transfer(UUID from, UUID to, double amount, String reason);

    /** @return top {@code limit} accounts sorted by balance, descending. */
    List<TopEntry> getTop(int limit);

    /** @return currency symbol from config (default "\u211F"). */
    String currencySymbol();

    /** Formats an amount with the currency symbol, e.g. {@code "12.50 \u211F"}. */
    String format(double amount);

    /**
     * Current global income multiplier for mob rewards
     * (managed via {@code /mfm multiplier ...} or {@link #setGlobalMultiplier}).
     */
    double getGlobalMultiplier();

    /**
     * Sets a temporary global mob-reward multiplier.
     *
     * @param multiplier value, e.g. 2.0
     * @param durationSeconds how long it lasts; {@code <= 0} removes it.
     */
    void setGlobalMultiplier(double multiplier, long durationSeconds);

    /** Kill/earnings statistics for the Money-From-Mobs part. */
    Optional<PlayerStats> getStats(UUID player);

    /** Convenience overloads for online players. */
    default double getBalance(ServerPlayer player) {
        return getBalance(player.getUUID());
    }

    default EconomyResponse deposit(ServerPlayer player, double amount, String reason) {
        return deposit(player.getUUID(), amount, reason);
    }

    default EconomyResponse withdraw(ServerPlayer player, double amount, String reason) {
        return withdraw(player.getUUID(), amount, reason);
    }

    /** @return the server this economy instance is bound to. */
    MinecraftServer server();

    /** Immutable top-list entry. */
    record TopEntry(UUID uuid, String lastKnownName, double balance) {
    }

    /** Immutable MFM statistics snapshot. */
    record PlayerStats(UUID uuid, long mobsKilled, double totalEarned) {
    }
}

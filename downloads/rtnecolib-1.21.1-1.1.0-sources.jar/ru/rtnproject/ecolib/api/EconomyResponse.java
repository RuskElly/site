package ru.rtnproject.ecolib.api;

/**
 * Result of an economy transaction (deposit / withdraw / set / transfer).
 *
 * @param amount     the amount that was involved in the transaction.
 * @param newBalance balance of the (primary) account after the transaction.
 * @param status     outcome of the transaction.
 * @param message    human-readable detail (empty on success).
 */
public record EconomyResponse(double amount, double newBalance, Status status, String message) {

    public enum Status {
        SUCCESS,
        INSUFFICIENT_FUNDS,
        INVALID_AMOUNT,
        ACCOUNT_NOT_FOUND,
        CANCELLED,
        FAILURE
    }

    public boolean success() {
        return status == Status.SUCCESS;
    }

    public static EconomyResponse ok(double amount, double newBalance) {
        return new EconomyResponse(amount, newBalance, Status.SUCCESS, "");
    }

    public static EconomyResponse fail(Status status, String message) {
        return new EconomyResponse(0, 0, status, message);
    }
}

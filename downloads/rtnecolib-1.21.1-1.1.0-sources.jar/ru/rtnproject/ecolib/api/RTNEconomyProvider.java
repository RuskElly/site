package ru.rtnproject.ecolib.api;

import org.jetbrains.annotations.Nullable;

/**
 * Static provider/service locator for {@link RTNEconomyAPI}.
 * <p>
 * The API instance exists only while a server (dedicated or integrated) is
 * running. Query it lazily — do not cache it across server restarts.
 *
 * <pre>{@code
 * RTNEconomyAPI eco = RTNEconomyProvider.get();      // throws if not ready
 * RTNEconomyAPI eco = RTNEconomyProvider.getOrNull(); // null if not ready
 * }</pre>
 */
public final class RTNEconomyProvider {

    private static volatile RTNEconomyAPI instance;

    /** @return the active economy API. @throws IllegalStateException if no server is running. */
    public static RTNEconomyAPI get() {
        RTNEconomyAPI api = instance;
        if (api == null) {
            throw new IllegalStateException(
                    "RTN EcoLib economy is not available (server not started yet?)");
        }
        return api;
    }

    /** @return the active economy API, or null when no server is running. */
    @Nullable
    public static RTNEconomyAPI getOrNull() {
        return instance;
    }

    public static boolean isAvailable() {
        return instance != null;
    }

    /** Internal — set by rtnecolib on server start/stop. Do not call. */
    public static void _set(@Nullable RTNEconomyAPI api) {
        instance = api;
    }

    private RTNEconomyProvider() {
    }
}

package ru.rtnproject.ecolib.mfm;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import ru.rtnproject.ecolib.EcoConfig;
import ru.rtnproject.ecolib.api.event.MobRewardEvent;
import ru.rtnproject.ecolib.economy.EconomyManager;
import ru.rtnproject.ecolib.economy.ServerLifecycleHandler;

/**
 * Money-From-Mobs analogue. Rewards the killer for any {@link LivingEntity}
 * death — vanilla or modded, because classification is based on generic
 * criteria ({@link Enemy} interface, {@link MobCategory}, max health, config
 * overrides), not on hardcoded entity lists.
 */
public final class MobRewardHandler {

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) {
            return;
        }
        if (victim instanceof Player) {
            return; // no rewards for killing players
        }
        EconomyManager eco = ServerLifecycleHandler.manager();
        if (eco == null) {
            return;
        }

        EntityType<?> type = victim.getType();
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(type);

        boolean boss = isBoss(victim, id);
        double base = baseReward(victim, id, boss);
        if (base <= 0) {
            return;
        }

        int combo = ComboTracker.onKill(killer);
        double globalMult = eco.getGlobalMultiplier();

        MobRewardEvent apiEvent = new MobRewardEvent(killer, victim, base, boss, combo, globalMult);
        if (NeoForge.EVENT_BUS.post(apiEvent).isCanceled()) {
            return;
        }

        double payout = EconomyManager.round(apiEvent.getReward() * combo * globalMult);
        if (payout <= 0) {
            return;
        }

        eco.deposit(killer.getUUID(), payout,
                "mob kill: " + id + (apiEvent.isBoss() ? " [BOSS]" : "") + " x" + combo);
        eco.recordKill(killer.getUUID(), payout);
        ComboTracker.addEarned(killer, payout);
        ComboTracker.showActionBar(killer, payout, eco.currencySymbol());
    }

    /**
     * Boss detection working for modded entities too:
     * config list -> vanilla boss classes -> max-health threshold.
     */
    private static boolean isBoss(LivingEntity victim, ResourceLocation id) {
        if (EcoConfig.isConfiguredBoss(id)) {
            return true;
        }
        if (victim instanceof EnderDragon || victim instanceof WitherBoss) {
            return true;
        }
        return victim.getMaxHealth() >= EcoConfig.BOSS_HEALTH_THRESHOLD.get();
    }

    private static double baseReward(LivingEntity victim, ResourceLocation id, boolean boss) {
        Double override = EcoConfig.overrideFor(id);
        if (override != null) {
            return override;
        }
        if (boss) {
            return EcoConfig.BOSS_REWARD.get();
        }
        if (isHostile(victim)) {
            return EcoConfig.HOSTILE_REWARD.get();
        }
        return EcoConfig.PASSIVE_REWARD.get();
    }

    /** Hostility check that also covers modded monsters. */
    private static boolean isHostile(LivingEntity victim) {
        if (victim instanceof Enemy) {
            return true;
        }
        MobCategory cat = victim.getType().getCategory();
        return cat == MobCategory.MONSTER;
    }
}

package ru.rtnproject.ecolib.mfm;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import ru.rtnproject.ecolib.EcoConfig;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-player kill combo state (server side).
 * <ul>
 *   <li>first kill starts a window of {@code comboWindowSeconds} (default 5s);</li>
 *   <li>each kill inside the window raises the combo up to {@code comboMax} (x3);</li>
 *   <li>no kill within the window — combo resets to x1.</li>
 * </ul>
 */
public final class ComboTracker {

    private static final class State {
        int combo = 0;
        long lastKillMillis = 0;
        double sessionEarned = 0;
    }

    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();

    private ComboTracker() {
    }

    /**
     * Registers a kill; returns the combo multiplier to apply for THIS kill.
     */
    public static int onKill(ServerPlayer player) {
        long now = System.currentTimeMillis();
        long window = EcoConfig.COMBO_WINDOW_SECONDS.get() * 1000L;
        int max = EcoConfig.COMBO_MAX.get();
        State s = STATES.computeIfAbsent(player.getUUID(), u -> new State());
        synchronized (s) {
            if (s.combo == 0 || now - s.lastKillMillis > window) {
                s.combo = 1;
                s.sessionEarned = 0;
            } else if (s.combo < max) {
                s.combo++;
            }
            s.lastKillMillis = now;
            return s.combo;
        }
    }

    public static void addEarned(ServerPlayer player, double amount) {
        State s = STATES.computeIfAbsent(player.getUUID(), u -> new State());
        synchronized (s) {
            s.sessionEarned += amount;
        }
    }

    public static int currentCombo(UUID player) {
        State s = STATES.get(player);
        if (s == null) {
            return 1;
        }
        synchronized (s) {
            long window = EcoConfig.COMBO_WINDOW_SECONDS.get() * 1000L;
            return (s.combo == 0 || System.currentTimeMillis() - s.lastKillMillis > window)
                    ? 1 : s.combo;
        }
    }

    /** Sends the pretty action bar with combo and earned money. */
    public static void showActionBar(ServerPlayer player, double earnedNow, String symbol) {
        if (!EcoConfig.ACTION_BAR.get()) {
            return;
        }
        State s = STATES.get(player.getUUID());
        int combo = s == null ? 1 : s.combo;
        double total = s == null ? earnedNow : s.sessionEarned;
        Component msg = Component.translatable("rtnecolib.actionbar.reward",
                formatMoney(earnedNow), symbol, combo, formatMoney(total));
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket(msg));
    }

    /** Called once a second — expires combos silently (no "combo lost" spam). */
    public static void tickSecond(MinecraftServer server) {
        long now = System.currentTimeMillis();
        long window = EcoConfig.COMBO_WINDOW_SECONDS.get() * 1000L;
        STATES.forEach((uuid, s) -> {
            boolean expired;
            synchronized (s) {
                expired = s.combo > 0 && now - s.lastKillMillis > window;
                if (expired) {
                    s.combo = 0;
                    s.sessionEarned = 0;
                }
            }
            if (expired && EcoConfig.ACTION_BAR.get()) {
                // Quietly clear the action bar so the last reward text doesn't linger.
                ServerPlayer p = server.getPlayerList().getPlayer(uuid);
                if (p != null) {
                    p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket(
                            Component.empty()));
                }
            }
        });
    }

    public static void clear(UUID player) {
        STATES.remove(player);
    }

    public static void clearAll() {
        STATES.clear();
    }

    private static String formatMoney(double v) {
        return v == Math.floor(v) && Math.abs(v) < 1e15
                ? String.valueOf((long) v)
                : String.format(java.util.Locale.ROOT, "%.2f", v);
    }
}

package ru.rtnproject.ecolib.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import ru.rtnproject.ecolib.EcoConfig;
import ru.rtnproject.ecolib.api.EconomyResponse;
import ru.rtnproject.ecolib.api.RTNEconomyAPI;
import ru.rtnproject.ecolib.economy.EconomyManager;
import ru.rtnproject.ecolib.economy.ServerLifecycleHandler;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * All rtnecolib commands.
 *
 * Player commands:
 *   /balance, /bal, /money, /баланс, /бал      — own balance
 *   /balance <player>                          — someone else's balance (admins, perm level 3)
 *   /baltop, /moneytop, /balancetop,
 *   /балтоп, /баланстоп                        — top-10 richest
 *   /pay <player> <amount>                     — transfer money
 *   /mfm info                         — personal MFM statistics
 *   /mfm top                          — top-10 hunters by total earnings
 *
 * Admin commands (permission level 3):
 *   /balset <player> <amount>
 *   /balgive <player> <amount>        (negative amount withdraws)
 *   /balreload                        — reload config caches + save + rebuild top
 *   /mfm multiplier add <mult> <sec>
 *   /mfm multiplier remove
 */
public final class CommandRegistrar {

    private static final SuggestionProvider<CommandSourceStack> ONLINE_PLAYERS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(
                    ctx.getSource().getServer().getPlayerList().getPlayers().stream()
                            .map(p -> p.getGameProfile().getName()), builder);

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        // ---- balance aliases: balance, bal, money, баланс, бал -----------
        // "<player>" branch is admin-only (permission level 3).
        for (String alias : new String[]{"balance", "bal", "money",
                "\u0431\u0430\u043b\u0430\u043d\u0441", "\u0431\u0430\u043b"}) {
            d.register(Commands.literal(alias)
                    .executes(CommandRegistrar::balanceSelf)
                    .then(Commands.argument("player", StringArgumentType.word())
                            .suggests(ONLINE_PLAYERS)
                            .requires(s -> s.hasPermission(3))
                            .executes(ctx -> balanceOther(ctx,
                                    StringArgumentType.getString(ctx, "player")))));
        }

        // ---- baltop aliases: baltop, moneytop, balancetop, балтоп, баланстоп
        for (String alias : new String[]{"baltop", "moneytop", "balancetop",
                "\u0431\u0430\u043b\u0442\u043e\u043f",
                "\u0431\u0430\u043b\u0430\u043d\u0441\u0442\u043e\u043f"}) {
            d.register(Commands.literal(alias).executes(CommandRegistrar::balTop));
        }

        // ---- pay ---------------------------------------------------------
        d.register(Commands.literal("pay")
                .then(Commands.argument("player", StringArgumentType.word())
                        .suggests(ONLINE_PLAYERS)
                        .then(Commands.argument("amount",
                                        DoubleArgumentType.doubleArg(0.01))
                                .executes(ctx -> pay(ctx,
                                        StringArgumentType.getString(ctx, "player"),
                                        DoubleArgumentType.getDouble(ctx, "amount"))))));

        // ---- admin: balset / balgive / balreload --------------------------
        d.register(Commands.literal("balset")
                .requires(s -> s.hasPermission(3))
                .then(Commands.argument("player", StringArgumentType.word())
                        .suggests(ONLINE_PLAYERS)
                        .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0))
                                .executes(ctx -> balSet(ctx,
                                        StringArgumentType.getString(ctx, "player"),
                                        DoubleArgumentType.getDouble(ctx, "amount"))))));

        d.register(Commands.literal("balgive")
                .requires(s -> s.hasPermission(3))
                .then(Commands.argument("player", StringArgumentType.word())
                        .suggests(ONLINE_PLAYERS)
                        .then(Commands.argument("amount", DoubleArgumentType.doubleArg(-1_000_000_000, 1_000_000_000))
                                .executes(ctx -> balGive(ctx,
                                        StringArgumentType.getString(ctx, "player"),
                                        DoubleArgumentType.getDouble(ctx, "amount"))))));

        d.register(Commands.literal("balreload")
                .requires(s -> s.hasPermission(3))
                .executes(CommandRegistrar::balReload));

        // ---- /mfm ----------------------------------------------------------
        d.register(Commands.literal("mfm")
                .then(Commands.literal("info").executes(CommandRegistrar::mfmInfo))
                .then(Commands.literal("top").executes(CommandRegistrar::mfmTop))
                .then(Commands.literal("multiplier")
                        .requires(s -> s.hasPermission(3))
                        .then(Commands.literal("add")
                                .then(Commands.argument("multiplier",
                                                DoubleArgumentType.doubleArg(0.1, 100))
                                        .then(Commands.argument("seconds",
                                                        IntegerArgumentType.integer(1, 86_400))
                                                .executes(ctx -> multiplierAdd(ctx,
                                                        DoubleArgumentType.getDouble(ctx, "multiplier"),
                                                        IntegerArgumentType.getInteger(ctx, "seconds"))))))
                        .then(Commands.literal("remove")
                                .executes(CommandRegistrar::multiplierRemove))));
    }

    // ------------------------------------------------------------------ impl

    private static EconomyManager eco(CommandContext<CommandSourceStack> ctx) {
        return ServerLifecycleHandler.manager();
    }

    private static int balanceSelf(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = ctx.getSource().getPlayer();
        EconomyManager eco = eco(ctx);
        if (player == null || eco == null) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.players_only"));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.balance.self",
                        Component.literal(eco.format(eco.getBalance(player.getUUID())))
                                .withStyle(ChatFormatting.GOLD)),
                false);
        return 1;
    }

    private static int balanceOther(CommandContext<CommandSourceStack> ctx, String name) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        Optional<UUID> target = eco.findByName(name);
        if (target.isEmpty()) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.player_not_found", name));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.balance.other",
                name, Component.literal(eco.format(eco.getBalance(target.get())))
                        .withStyle(ChatFormatting.GOLD)), false);
        return 1;
    }

    private static int balTop(CommandContext<CommandSourceStack> ctx) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        List<RTNEconomyAPI.TopEntry> top = eco.getTop(10);
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.baltop.header")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        int i = 1;
        for (RTNEconomyAPI.TopEntry e : top) {
            final int place = i++;
            ctx.getSource().sendSuccess(() -> Component.literal(" " + place + ". ")
                    .withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal(e.lastKnownName().isEmpty()
                            ? e.uuid().toString().substring(0, 8) : e.lastKnownName())
                            .withStyle(ChatFormatting.WHITE))
                    .append(Component.literal(" — " + eco.format(e.balance()))
                            .withStyle(ChatFormatting.GOLD)), false);
        }
        if (top.isEmpty()) {
            ctx.getSource().sendSuccess(() ->
                    Component.translatable("rtnecolib.baltop.empty"), false);
        }
        return 1;
    }

    private static int pay(CommandContext<CommandSourceStack> ctx, String name, double amount) {
        ServerPlayer sender = ctx.getSource().getPlayer();
        EconomyManager eco = eco(ctx);
        if (sender == null || eco == null) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.players_only"));
            return 0;
        }
        Optional<UUID> target = eco.findByName(name);
        if (target.isEmpty()) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.player_not_found", name));
            return 0;
        }
        if (target.get().equals(sender.getUUID())) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.pay.self"));
            return 0;
        }
        EconomyResponse r = eco.transfer(sender.getUUID(), target.get(), amount, "/pay");
        if (!r.success()) {
            if (r.status() == EconomyResponse.Status.INSUFFICIENT_FUNDS) {
                ctx.getSource().sendFailure(Component.translatable("rtnecolib.pay.no_money"));
            } else {
                ctx.getSource().sendFailure(Component.literal(r.message()));
            }
            return 0;
        }
        String formatted = eco.format(amount);
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.pay.sent",
                Component.literal(formatted).withStyle(ChatFormatting.GOLD), name), false);
        ServerPlayer targetPlayer = ctx.getSource().getServer().getPlayerList().getPlayer(target.get());
        if (targetPlayer != null) {
            targetPlayer.sendSystemMessage(Component.translatable("rtnecolib.pay.received",
                    Component.literal(formatted).withStyle(ChatFormatting.GOLD),
                    sender.getGameProfile().getName()));
        }
        return 1;
    }

    private static int balSet(CommandContext<CommandSourceStack> ctx, String name, double amount) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        Optional<UUID> target = eco.findByName(name);
        if (target.isEmpty()) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.player_not_found", name));
            return 0;
        }
        EconomyResponse r = eco.setBalance(target.get(), amount, "/balset by " + ctx.getSource().getTextName());
        if (!r.success()) {
            ctx.getSource().sendFailure(Component.literal(r.message()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.balset.done",
                name, Component.literal(eco.format(r.newBalance())).withStyle(ChatFormatting.GOLD)), true);
        return 1;
    }

    private static int balGive(CommandContext<CommandSourceStack> ctx, String name, double amount) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        Optional<UUID> target = eco.findByName(name);
        if (target.isEmpty()) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.player_not_found", name));
            return 0;
        }
        EconomyResponse r = amount >= 0
                ? eco.deposit(target.get(), amount, "/balgive by " + ctx.getSource().getTextName())
                : eco.withdraw(target.get(), -amount, "/balgive by " + ctx.getSource().getTextName());
        if (!r.success()) {
            ctx.getSource().sendFailure(Component.literal(r.status() + ": " + r.message()));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.balgive.done",
                Component.literal(eco.format(amount)).withStyle(ChatFormatting.GOLD),
                name,
                Component.literal(eco.format(r.newBalance())).withStyle(ChatFormatting.GOLD)), true);
        return 1;
    }

    private static int balReload(CommandContext<CommandSourceStack> ctx) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        EcoConfig.rebuildCaches();
        eco.save(true);
        eco.rebuildTops();
        ctx.getSource().sendSuccess(() ->
                Component.translatable("rtnecolib.reload.done"), true);
        return 1;
    }

    private static int mfmInfo(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = ctx.getSource().getPlayer();
        EconomyManager eco = eco(ctx);
        if (player == null || eco == null) {
            ctx.getSource().sendFailure(Component.translatable("rtnecolib.error.players_only"));
            return 0;
        }
        var stats = eco.getStats(player.getUUID())
                .orElse(new RTNEconomyAPI.PlayerStats(player.getUUID(), 0, 0));
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.mfm.info",
                Component.literal(String.valueOf(stats.mobsKilled())).withStyle(ChatFormatting.YELLOW),
                Component.literal(eco.format(stats.totalEarned())).withStyle(ChatFormatting.GOLD)), false);
        double mult = eco.getGlobalMultiplier();
        if (mult != 1.0D) {
            ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.mfm.mult_active",
                    mult, eco.multiplierSecondsLeft()), false);
        }
        return 1;
    }

    private static int mfmTop(CommandContext<CommandSourceStack> ctx) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        List<RTNEconomyAPI.TopEntry> top = eco.getEarnedTop(10);
        ctx.getSource().sendSuccess(() -> Component.translatable("rtnecolib.mfm.top_header")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        int i = 1;
        for (RTNEconomyAPI.TopEntry e : top) {
            final int place = i++;
            ctx.getSource().sendSuccess(() -> Component.literal(" " + place + ". ")
                    .withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal(e.lastKnownName().isEmpty()
                            ? e.uuid().toString().substring(0, 8) : e.lastKnownName())
                            .withStyle(ChatFormatting.WHITE))
                    .append(Component.literal(" — " + eco.format(e.balance()))
                            .withStyle(ChatFormatting.GOLD)), false);
        }
        if (top.isEmpty()) {
            ctx.getSource().sendSuccess(() ->
                    Component.translatable("rtnecolib.baltop.empty"), false);
        }
        return 1;
    }

    private static int multiplierAdd(CommandContext<CommandSourceStack> ctx, double mult, int seconds) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        eco.setGlobalMultiplier(mult, seconds);
        ctx.getSource().sendSuccess(() -> Component.translatable(
                "rtnecolib.mfm.mult_set", mult, seconds), true);
        // broadcast to everyone
        ctx.getSource().getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("rtnecolib.mfm.mult_broadcast", mult, seconds)
                        .withStyle(ChatFormatting.LIGHT_PURPLE), false);
        return 1;
    }

    private static int multiplierRemove(CommandContext<CommandSourceStack> ctx) {
        EconomyManager eco = eco(ctx);
        if (eco == null) return 0;
        eco.setGlobalMultiplier(1.0D, 0);
        ctx.getSource().sendSuccess(() ->
                Component.translatable("rtnecolib.mfm.mult_removed"), true);
        return 1;
    }
}
